/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{ts,tsx}", "./tool-name.html"],
  theme: {
    extend: {},
  },
  plugins: [],
};
