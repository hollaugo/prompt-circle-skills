---
name: excalidraw-diagrams
description: >
  Create professional, high-fidelity Excalidraw diagrams from natural language for business flows,
  system architectures, pipelines, and process maps. Use this skill whenever the user asks to draw,
  diagram, visualize, map, or create any kind of flowchart, architecture, process flow, pipeline,
  workflow (e.g., "email handling flow", "accounting process", "system architecture", "data pipeline",
  "onboarding process"). Generates clean, production-quality diagrams that match the layered,
  color-coded style shown in the HR App Architecture reference. Always use this skill for
  architecture diagrams, business flows, technical pipelines, and process maps — even if the user
  just says "draw" or "show me how X works".
---

# Excalidraw Business Diagrams Skill

This skill produces clean, high-fidelity Excalidraw diagrams from natural language using the
`yctimlin/mcp_excalidraw` MCP server (26-tool canvas toolkit). For quick one-shot diagrams
you can also use `excalidraw/excalidraw-mcp` (official remote server at mcp.excalidraw.com).

Read `references/tool-reference.md` for the full MCP tool API.
Read `references/design-system.md` for the visual language, colors, sizing, and layout rules.
Read `references/prompt-patterns.md` for proven prompt patterns for common diagram types.

---

## Choosing Your Tool

| Situation | Use |
|---|---|
| Iterative refinement, complex multi-layer architecture | `yctimlin/mcp_excalidraw` (26 tools, live canvas) |
| Quick one-shot diagram, no local server needed | `excalidraw/excalidraw-mcp` (remote, mcp.excalidraw.com) |

---

## Core Workflow (yctimlin MCP — 26-tool canvas)

Follow these phases every time. Do not skip phases.

### Phase 1 — Setup Check
```
1. Call read_diagram_guide            → load color palette, sizing rules, anti-patterns
2. Call describe_scene                → check if canvas has existing content
3. If canvas dirty: call snapshot_scene("pre-[diagram-name]") to save state
4. Call clear_canvas                  → start fresh
```

### Phase 2 — Plan Before Drawing
Before placing any elements, mentally lay out the diagram:
- Define **layers** (client / app / server / database — see design-system.md)
- Decide **left-to-right** or **top-to-bottom** flow direction
- Identify grouping containers (rounded rectangles as swimlanes/zones)
- Assign zone colors (see design-system.md color palette)
- Note connector types: straight arrows for sequential flow, curved for callbacks

### Phase 3 — Build Layer by Layer
Draw in this order to avoid z-index issues:
```
1. Background zone rectangles (containers/swimlanes)      → batch_create_elements
2. Title text labels for each zone                        → batch_create_elements
3. Process/service boxes inside zones                     → batch_create_elements
4. Connecting arrows with labels                          → batch_create_elements
5. Icon/image elements (optional)                         → create_element per image
```

Always use `batch_create_elements` for 3+ elements. It's faster and preserves IDs.

### Phase 4 — Inspect and Refine
```
1. get_canvas_screenshot              → visually verify layout
2. describe_scene                     → check element count / IDs
3. Identify misalignments via screenshot
4. align_elements / distribute_elements as needed
5. set_viewport({ scrollToContent: true }) → zoom to fit
6. get_canvas_screenshot again        → final verification
```

### Phase 5 — Export
```
Option A: export_to_excalidraw_url    → shareable link (recommended)
Option B: export_scene                → .excalidraw JSON file
Option C: export_to_image            → PNG (requires browser open)
```

---

## Layout Conventions for Business Diagrams

### Flow Directions
- **Top-to-bottom**: approval chains, hierarchies, data pipelines
- **Left-to-right**: process flows, customer journeys, email handling
- **Swimlane (horizontal bands)**: multi-actor processes (e.g. customer → system → finance)

### Zone/Layer Sizing
| Zone type | Recommended width | Height per row |
|---|---|---|
| Top client layer | Full canvas width | 120–160px |
| Mid application layer | Full canvas width | 200–260px |
| Bottom server/DB layer | Full canvas width | 300–400px |
| Side panel (proxy, cache) | 200–250px | Match adjacent layer |

### Spacing Rules
- Between zones: 40px vertical gap
- Between sibling boxes inside a zone: 30–40px horizontal gap
- Arrow label offset: 10–12px from midpoint
- Canvas padding: 60px all sides

### Element Sizing
| Element type | Width | Height |
|---|---|---|
| Primary service box | 200–240px | 70–90px |
| Sub-component box | 140–180px | 50–70px |
| Zone container | Calculated from children | Calculated |
| Arrow label text | Auto | 20px |

---

## Diagram Types & Quick Recipes

### Business Process Flow (e.g., Inbound Email Handling)
```
Zones: [Inbound Channel] → [Triage/Routing] → [Processing] → [Response/Archive]
Colors: Blue (entry) → Yellow (decision) → Green (processing) → Purple (output)
Arrows: Labeled with conditions ("if spam", "if urgent", "forward to")
```

### Accounting / Finance Flow
```
Zones: [Source Documents] → [Entry/Recording] → [Reconciliation] → [Reporting]
Decision diamonds for: approval required?, amount > threshold?
Use swimlanes by role: Clerk / Accountant / CFO
```

### System Architecture (like the HR App sample)
```
Zones (top to bottom):
  [Client] — green background, lists features
  [Application Layer] — blue, shows middleware/router
  [On-Premise/Server] — blue, shows compute + storage
Side panels: Reverse Proxy, Auth annotations
Arrows: JWT Auth label, Request/Response, Inference, DB Operations
```

### Data Pipeline
```
Left-to-right: [Ingest] → [Transform] → [Store] → [Serve]
Show parallelism with stacked boxes
Label throughput/latency on arrows
```

---

## Prompt Patterns That Work Well

When invoking this skill, structure your prompt like this:

```
Draw an Excalidraw diagram for [PROCESS NAME].

Actors/Systems involved: [list them]
Flow direction: [top-to-bottom | left-to-right | swimlane]
Key steps:
  1. [step]
  2. [step]
  ...
Decision points: [list any yes/no branches]
Style: Match the HR App Architecture style — layered zones, color-coded, clean arrows with labels.
```

### Example Prompts

**Email Handling Flow:**
> "Draw an Excalidraw diagram for inbound email handling. Actors: Customer, Email Server, AI Triage, Support Agent, CRM. Left-to-right flow. Steps: receive → classify → route → respond → log. Decision: is it spam? is it urgent? Use the layered zone style."

**Accounting Entry Flow:**
> "Create an Excalidraw business flow for recording an accounting transaction. Swimlane layout with roles: Clerk, Accountant, CFO. Steps: receive invoice → create journal entry → get approval (if > $5k) → post to ledger → reconcile monthly."

**Architecture Diagram:**
> "Draw a system architecture diagram like the HR App sample. Client layer with 3 features. App layer with an AI router. Server layer with Ollama models + database. Add a reverse proxy on the right side. Use the same green/blue color scheme."

---

## Quality Checklist

Before exporting, verify:
- [ ] All zones have a visible border and background fill
- [ ] Arrow labels describe WHAT flows (not just "→")
- [ ] Font size ≥ 16 for zone titles, ≥ 14 for component labels
- [ ] No overlapping elements (use describe_scene to check coordinates)
- [ ] Decision points use diamond shapes
- [ ] External services / 3rd parties visually differentiated (dashed border)
- [ ] Canvas viewport set to show full diagram (set_viewport scrollToContent)
- [ ] Screenshot taken and verified before export

---

## Common Mistakes to Avoid

| Mistake | Fix |
|---|---|
| Drawing elements one-by-one | Use batch_create_elements |
| Not calling read_diagram_guide first | Always read it — it has color codes |
| Arrows that don't connect (floating) | Set startBinding/endBinding to element IDs |
| Overcrowded zones | Increase zone height, reduce font size to 14px minimum |
| Unlabeled arrows | Every arrow should have a label |
| Using default white backgrounds | Always set zone backgroundColor |
| Exporting before verifying screenshot | Always screenshot → verify → then export |

---

## MCP Server Setup Reference

### Option A: Official Remote (excalidraw/excalidraw-mcp)
No setup needed. Add to Claude Desktop:
```json
{
  "mcpServers": {
    "excalidraw": {
      "url": "https://mcp.excalidraw.com"
    }
  }
}
```
Prompts: "Draw an architecture diagram showing [describe]" → diagram renders inline.

### Option B: yctimlin/mcp_excalidraw (Full 26-tool canvas)
```bash
# Terminal 1: Start canvas UI
PORT=3000 npm run canvas
# Open http://localhost:3000

# Terminal 2: MCP server
EXPRESS_SERVER_URL=http://localhost:3000 node dist/index.js
```

Claude Desktop config:
```json
{
  "mcpServers": {
    "excalidraw": {
      "command": "node",
      "args": ["/absolute/path/to/mcp_excalidraw/dist/index.js"],
      "env": {
        "EXPRESS_SERVER_URL": "http://localhost:3000",
        "ENABLE_CANVAS_SYNC": "true"
      }
    }
  }
}
```

Docker (simplest):
```bash
docker run -d -p 3000:3000 ghcr.io/yctimlin/mcp_excalidraw-canvas:latest
```

---

See `references/tool-reference.md` for all 26 MCP tool signatures.
See `references/design-system.md` for the full visual design language.
See `references/prompt-patterns.md` for 10 ready-to-use diagram prompts.
